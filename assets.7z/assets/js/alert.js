function myFunction() {
    alert("Click Okey to send");
}